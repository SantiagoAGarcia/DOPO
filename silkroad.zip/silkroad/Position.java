/**
 * Representa una posición en 1D (solo eje X).
 * 
 * @author Buitrago - Garcia
 * @version 2.0
 */
public class Position {
    private int xPosition;
    
    /**
     * Constructor que crea una nueva posición con la coordenada X especificada.
     * 
     * @param x La coordenada X de la posición
     */
    public Position(int x) {
        this.xPosition = x;
    }
    
    /**
     * Obtiene la coordenada X de esta posición.
     * 
     * @return La coordenada X actual
     */
    public int getX() {
        return xPosition;
    }
    
    /**
     * Obtiene el valor de la posición (equivalente a getX()).
     * 
     * @return El valor de la coordenada X
     */
    public int getValue() {
        return xPosition;
    }
    
    /**
     * Establece una nueva coordenada X para esta posición.
     * 
     * @param x La nueva coordenada X
     */
    public void setX(int x) {
        this.xPosition = x;
    }
    
    /**
     * Calcula la distancia absoluta entre esta posición y otra posición.
     * 
     * @param other La otra posición para calcular la distancia
     * @return La distancia absoluta entre las dos posiciones
     */
    public int distanceToOther(Position other) {
        return Math.abs(this.xPosition - other.xPosition);
    }
    
    /**
     * Compara esta posición con otro objeto para determinar si son iguales.
     * Dos posiciones son iguales si tienen la misma coordenada X.
     * 
     * @param obj El objeto a comparar
     * @return true si las posiciones son iguales, false en caso contrario
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Position position = (Position) obj;
        return xPosition == position.xPosition;
    }
    
    /**
     * Genera un código hash para esta posición basado en su coordenada X.
     * 
     * @return El código hash de esta posición
     */
    @Override
    public int hashCode() {
        return Integer.hashCode(xPosition);
    }
    
    /**
     * Devuelve una representación en cadena de esta posición.
     * 
     * @return Una cadena en formato "Position(x)" donde x es la coordenada
     */
    @Override
    public String toString() {
        return "Position(" + xPosition + ")";
    }
}