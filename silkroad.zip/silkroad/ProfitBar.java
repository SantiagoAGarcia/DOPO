/**
 * Barra de seguimiento de profit en SilkRoad.
 * 
 * @author Buitrago - Garcia
 * @version 2.0
 */
public class ProfitBar {
    private int currentProfit;
    private int maxProfit;
    private Rectangle bar;
    private String label;
    
    /**
     * Constructor que inicializa la barra de profit con un valor máximo.
     * El profit actual se inicializa en 0.
     * 
     * @param maxProfit El valor máximo de profit que puede mostrar la barra
     */
    public ProfitBar(int maxProfit) {
        this.maxProfit = maxProfit;
        this.currentProfit = 0;
        this.bar = null;
        this.label = "";
    }
    
    /**
     * Actualiza el valor actual de profit mostrado en la barra.
     * 
     * @param profit El nuevo valor de profit a mostrar
     */
    public void updateProfit(int profit) {
        this.currentProfit = profit;
    }
    
    /**
     * Obtiene el valor actual de profit mostrado en la barra.
     * 
     * @return El profit actual
     */
    public int getCurrentProfit() {
        return currentProfit;
    }
    
    /**
     * Obtiene el valor máximo de profit que puede mostrar la barra.
     * 
     * @return El profit máximo
     */
    public int getMaxProfit() {
        return maxProfit;
    }
    
    /**
     * Establece un nuevo valor máximo para la barra de profit.
     * 
     * @param maxProfit El nuevo valor máximo de profit
     */
    public void setMaxProfit(int maxProfit) {
        this.maxProfit = maxProfit;
    }
    
    /**
     * Reinicia la barra de profit, estableciendo tanto el profit actual
     * como el máximo en 0.
     */
    public void reset() {
        this.currentProfit = 0;
        this.maxProfit = 0;
    }
}