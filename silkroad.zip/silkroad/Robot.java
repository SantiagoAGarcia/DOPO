import java.util.*;

/**
 * Representa un robot en SilkRoad.
 * Cada robot conoce sus propios movimientos y ganancias en cada movimiento.
 * NO usa ID - funciona por referencia de objeto.
 * 
 * @author Buitrago - Garcia
 * @version 2.2 Refactored - Sin IDs
 */
public class Robot {
    private Position position;
    private Position initialPosition;
    private int collectedTenges;
    private Circle shape;
    private boolean active;
    private Set<Store> visitedStores;
    private List<Position> movementHistory;
    private List<Integer> profitsPerMove; // Para requisito 13
    
    /**
     * Constructor que crea un robot con posición inicial especificada.
     * 
     * @param x La posición inicial en el eje X
     */
    public Robot(int x) {
        this.position = new Position(x);
        this.initialPosition = new Position(x);
        this.collectedTenges = 0;
        this.active = true;
        this.shape = null;
        this.visitedStores = new HashSet<>();
        this.movementHistory = new ArrayList<>();
        this.movementHistory.add(new Position(x));
        this.profitsPerMove = new ArrayList<>();
        this.profitsPerMove.add(0); // Profit inicial es 0 (no se ha movido)
    }
    
    /**
     * Obtiene la posición actual del robot.
     * 
     * @return La posición actual del robot
     */
    public Position getPosition() {
        return position;
    }
    
    /**
     * Obtiene la posición inicial del robot (donde fue creado).
     * 
     * @return La posición inicial del robot
     */
    public Position getInitialPosition() {
        return initialPosition;
    }
    
    /**
     * NUEVO: Obtiene el arreglo de profits por cada movimiento.
     * Esta es la responsabilidad del robot según el requisito 13.
     * 
     * @return Arreglo con las ganancias obtenidas en cada movimiento
     */
    public int[] getProfitsPerMove() {
        int[] profits = new int[profitsPerMove.size()];
        for (int i = 0; i < profitsPerMove.size(); i++) {
            profits[i] = profitsPerMove.get(i);
        }
        return profits;
    }
    
    /**
     * NUEVO: Registra el profit obtenido en un movimiento.
     * Debe llamarse cada vez que el robot se mueve y potencialmente recolecta.
     * 
     * @param profit El profit obtenido en este movimiento (puede ser 0 si no recolectó)
     */
    public void recordProfit(int profit) {
        profitsPerMove.add(profit);
    }
    
    /**
     * Mueve el robot a una nueva posición si está activo.
     * Agrega la nueva posición al historial de movimiento.
     * 
     * @param newPos La nueva posición a la cual mover el robot
     */
    public void moveToNewPos(Position newPos) {
        if (active && newPos != null) {
            this.position = new Position(newPos.getX());
            this.movementHistory.add(new Position(newPos.getX()));
        }
    }
    
    /**
     * Método sobrecargado para mover el robot usando una coordenada entera.
     * 
     * @param x La coordenada X de la nueva posición
     */
    public void moveToNewPos(int x) {
        moveToNewPos(new Position(x));
    }
    
    /**
     * Reinicia el robot a su estado inicial.
     * Limpia historial de movimientos, profits, tenges y tiendas visitadas.
     */
    public void reset() {
        this.position = new Position(initialPosition.getX());
        this.collectedTenges = 0;
        this.visitedStores.clear();
        this.movementHistory.clear();
        this.movementHistory.add(new Position(initialPosition.getX()));
        this.profitsPerMove.clear();
        this.profitsPerMove.add(0); // Estado inicial
    }
    
    /**
     * Recolecta una cantidad específica de tenges si el robot está activo.
     * 
     * @param tenges La cantidad de tenges a recolectar (debe ser positiva)
     */
    public void collect(int tenges) {
        if (active && tenges > 0) {
            collectedTenges += tenges;
        }
    }
    
    /**
     * Recolecta tenges de una tienda específica si está en la misma posición.
     * Registra la tienda como visitada y actualiza los tenges recolectados.
     * También registra el profit obtenido en este movimiento.
     * 
     * @param store La tienda de la cual recolectar tenges
     * @return La cantidad de tenges recolectados (profit del movimiento)
     */
    public int collectFromStore(Store store) {
        if (!active || store == null || !store.isActive()) {
            return 0;
        }
        
        // Verificar posición
        if (this.position.getX() != store.getPositionX()) {
            return 0;
        }
        
        int collected = store.collect(store.getTenges());
        this.collectedTenges += collected;
        this.visitedStores.add(store);
        
        // Registrar el profit de este movimiento
        this.recordProfit(collected);
        
        return collected;
    }
    
    /**
     * Obtiene la cantidad total de tenges recolectados por el robot.
     * 
     * @return El total de tenges recolectados
     */
    public int getCollectedTenges() {
        return collectedTenges;
    }
    
    /**
     * Desactiva el robot, impidiendo futuras operaciones.
     */
    public void remove() {
        active = false;
    }
    
    /**
     * Verifica si el robot está activo.
     * 
     * @return true si el robot está activo, false en caso contrario
     */
    public boolean isActive() {
        return active;
    }
    
    /**
     * Verifica si el robot ha visitado una tienda específica.
     * 
     * @param store La tienda a verificar
     * @return true si el robot ha visitado la tienda, false en caso contrario
     */
    public boolean hasVisited(Store store) {
        return store != null && visitedStores.contains(store);
    }
    
    /**
     * Obtiene una copia del conjunto de tiendas visitadas.
     * 
     * @return Un conjunto con las referencias a las tiendas visitadas
     */
    public Set<Store> getVisitedStores() {
        return new HashSet<>(visitedStores);
    }
    
    /**
     * Obtiene el número total de tiendas visitadas por el robot.
     * 
     * @return El número de tiendas visitadas
     */
    public int getVisitedStoreCount() {
        return visitedStores.size();
    }
    
    /**
     * Obtiene una copia del historial completo de movimientos del robot.
     * 
     * @return Una lista con todas las posiciones por las que ha pasado el robot
     */
    public List<Position> getMovementHistory() {
        return new ArrayList<>(movementHistory);
    }
    
    /**
     * Calcula la distancia total recorrida por el robot basada en su historial de movimiento.
     * 
     * @return La distancia total recorrida
     */
    public int getTotalDistanceTraveled() {
        int totalDistance = 0;
        for (int i = 1; i < movementHistory.size(); i++) {
            totalDistance += movementHistory.get(i - 1).distanceToOther(movementHistory.get(i));
        }
        return totalDistance;
    }
    
    /**
     * Calcula la eficiencia del robot como la relación entre tenges recolectados y distancia recorrida.
     * 
     * @return La eficiencia del robot (tenges por unidad de distancia), 0 si no se ha movido
     */
    public double getEfficiency() {
        int distance = getTotalDistanceTraveled();
        return distance > 0 ? (double) collectedTenges / distance : 0;
    }
    
    /**
     * Verifica si el robot puede moverse a una posición específica.
     * 
     * @param targetPosition La posición objetivo
     * @return true si el robot puede moverse (está activo y la posición es válida), false en caso contrario
     */
    public boolean canMoveTo(Position targetPosition) {
        return active && targetPosition != null;
    }
    
    /**
     * Calcula la distancia entre el robot y una tienda específica.
     * 
     * @param store La tienda para calcular la distancia
     * @return La distancia a la tienda, o Integer.MAX_VALUE si la tienda es inválida
     */
    public int distanceToStore(Store store) {
        if (store == null || store.isRemoved()) {
            return Integer.MAX_VALUE;
        }
        return Math.abs(position.getX() - store.getPositionX());
    }
    
    @Override
    public String toString() {
        return "Robot{position=" + position.getX() + 
               ", collectedTenges=" + collectedTenges + ", active=" + active + 
               ", visitedStores=" + visitedStores.size() + "}";
    }
}