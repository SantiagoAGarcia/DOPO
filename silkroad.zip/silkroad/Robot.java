import java.util.*;

/**
 * Representa un robot en SilkRoad.
 * Los robots recolectan tenges de las tiendas.
 * 
 * @author Buitrago - Garcia
 * @version 2.0
 */
public class Robot {
    private int id;
    private Position position;
    private Position initialPosition;
    private int collectedTenges;
    private Circle shape;
    private boolean active;
    private Set<Integer> visitedStores;
    private List<Position> movementHistory;
    
    /**
     * Constructor que crea un robot con ID y posición inicial especificados.
     * Inicializa el robot como activo, sin tenges recolectados y con historial de movimiento vacío.
     * 
     * @param id El identificador único del robot
     * @param x La posición inicial en el eje X
     */
    public Robot(int id, int x) {
        this.id = id;
        this.position = new Position(x);
        this.initialPosition = new Position(x);
        this.collectedTenges = 0;
        this.active = true;
        this.shape = null;
        this.visitedStores = new HashSet<>();
        this.movementHistory = new ArrayList<>();
        this.movementHistory.add(new Position(x));
    }
    
    /**
     * Obtiene el identificador único del robot.
     * 
     * @return El ID del robot
     */
    public int getId() {
        return id;
    }
    
    /**
     * Obtiene la posición actual del robot.
     * 
     * @return La posición actual del robot
     */
    public Position getPosition() {
        return position;
    }
    
    /**
     * Obtiene la posición inicial del robot (donde fue creado).
     * 
     * @return La posición inicial del robot
     */
    public Position getInitialPosition() {
        return initialPosition;
    }
    
    /**
     * Mueve el robot a una nueva posición si está activo.
     * Agrega la nueva posición al historial de movimiento.
     * 
     * @param newPos La nueva posición a la cual mover el robot
     */
    public void moveToNewPos(Position newPos) {
        if (active && newPos != null) {
            this.position = new Position(newPos.getX());
            this.movementHistory.add(new Position(newPos.getX()));
        }
    }
    
    /**
     * Método sobrecargado para mover el robot usando una coordenada enttera.
     * 
     * @param x La coordenada X de la nueva posición
     */
    public void moveToNewPos(int x) {
        moveToNewPos(new Position(x));
    }
    
    /**
     * Reinicia el robot a su estado inicial.
     * Regresa a la posición inicial, limpia los tenges recolectados,
     * las tiendas visitadas y el historial de movimiento.
     */
    public void reset() {
        this.position = new Position(initialPosition.getX());
        this.collectedTenges = 0;
        this.visitedStores.clear();
        this.movementHistory.clear();
        this.movementHistory.add(new Position(initialPosition.getX()));
    }
    
    /**
     * Recolecta una cantidad específica de tenges si el robot está activo.
     * 
     * @param tenges La cantidad de tenges a recolectar (debe ser positiva)
     */
    public void collect(int tenges) {
        if (active && tenges > 0) {
            collectedTenges += tenges;
        }
    }
    
    /**
     * Recolecta tenges de una tienda específica si está en la misma posición.
     * Registra la tienda como visitada y actualiza los tenges recolectados.
     * 
     * @param store La tienda de la cual recolectar tenges
     * @return La cantidad de tenges recolectados, 0 si no se pudo recolectar
     */
    public int collectFromStore(Store store) {
    if (!active || store == null || !store.isActive()) {
        return 0;
    }
    
    // Verificar posición
    if (this.position.getX() != store.getPositionX()) {
        return 0;
    }
    
    int collected = store.collect(store.getTenges());
    this.collectedTenges += collected;
    this.visitedStores.add(store.getId());
    
    return collected;
    }
    
    /**
     * Obtiene la cantidad total de tenges recolectados por el robot.
     * 
     * @return El total de tenges recolectados
     */
    public int getCollectedTenges() {
        return collectedTenges;
        }
    
    /**
     * Desactiva el robot, impidiendo futuras operaciones.
     */
    public void remove() {
        active = false;
    }
    
    /**
     * Verifica si el robot está activo.
     * 
     * @return true si el robot está activo, false en caso contrario
     */
    public boolean isActive() {
        return active;
    }
    
    /**
     * Verifica si el robot ha visitado una tienda específica.
     * 
     * @param store La tienda a verificar
     * @return true si el robot ha visitado la tienda, false en caso contrario
     */
    public boolean hasVisited(Store store) {
        return store != null && visitedStores.contains(store.getId());
    }
    
    /**
     * Verifica si el robot ha visitado una tienda por su ID.
     * 
     * @param storeId El ID de la tienda a verificar
     * @return true si el robot ha visitado la tienda, false en caso contrario
     */
    public boolean hasVisitedStore(int storeId) {
        return visitedStores.contains(storeId);
    }
    
    /**
     * Obtiene una copia del conjunto de IDs de tiendas visitadas.
     * 
     * @return Un conjunto con los IDs de las tiendas visitadas
     */
    public Set<Integer> getVisitedStores() {
        return new HashSet<>(visitedStores);
    }
    
    /**
     * Obtiene el número total de tiendas visitadas por el robot.
     * 
     * @return El número de tiendas visitadas
     */
    public int getVisitedStoreCount() {
        return visitedStores.size();
    }
    
    /**
     * Obtiene una copia del historial completo de movimientos del robot.
     * 
     * @return Una lista con todas las posiciones por las que ha pasado el robot
     */
    public List<Position> getMovementHistory() {
        return new ArrayList<>(movementHistory);
    }
    
    /**
     * Calcula la distancia total recorrida por el robot basada en su historial de movimiento.
     * 
     * @return La distancia total recorrida
     */
    public int getTotalDistanceTraveled() {
        int totalDistance = 0;
        for (int i = 1; i < movementHistory.size(); i++) {
            totalDistance += movementHistory.get(i - 1).distanceToOther(movementHistory.get(i));
        }
        return totalDistance;
    }
    
    /**
     * Calcula la eficiencia del robot como la relación entre tenges recolectados y distancia recorrida.
     * 
     * @return La eficiencia del robot (tenges por unidad de distancia), 0 si no se ha movido
     */
    public double getEfficiency() {
        int distance = getTotalDistanceTraveled();
        return distance > 0 ? (double) collectedTenges / distance : 0;
    }
    
    /**
     * Verifica si el robot puede moverse a una posición específica.
     * 
     * @param targetPosition La posición objetivo
     * @return true si el robot puede moverse (está activo y la posición es válida), false en caso contrario
     */
    public boolean canMoveTo(Position targetPosition) {
        return active && targetPosition != null;
    }
    
    /**
     * Calcula la distancia entre el robot y una tienda específica.
     * 
     * @param store La tienda para calcular la distancia
     * @return La distancia a la tienda, o Integer.MAX_VALUE si la tienda es inválida
     */
    public int distanceToStore(Store store) {
        if (store == null || store.isRemoved()) {
            return Integer.MAX_VALUE;
        }
        return Math.abs(position.getX() - store.getPositionX());
    }
    
    /**
     * Devuelve una representación en cadena del robot con sus principales atributos.
     * 
     * @return Una cadena describiendo el estado actual del robot
     */
    @Override
    public String toString() {
        return "Robot{id=" + id + ", position=" + position.getX() + 
               ", collectedTenges=" + collectedTenges + ", active=" + active + 
               ", visitedStores=" + visitedStores.size() + "}";
    }
    
    /**
     * Compara este robot con otro objeto para determinar si son iguales.
     * Dos robots son iguales si tienen el mismo ID.
     * 
     * @param obj El objeto a comparar
     * @return true si los robots son iguales, false en caso contrario
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Robot robot = (Robot) obj;
        return id == robot.id;
    }
    
    /**
     * Genera un código hash para este robot basado en su ID.
     * 
     * @return El código hash del robot
     */
    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }
}