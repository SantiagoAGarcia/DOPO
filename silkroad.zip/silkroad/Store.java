/**
 * Representa una tienda en SilkRoad.
 * Cada tienda conoce sus propios datos incluyendo cuántas veces ha sido vaciada.
 * NO usa ID - funciona por referencia de objeto.
 * 
 * @author Buitrago - Garcia
 * @version 2.2 Refactored - Sin IDs
 */
public class Store {
    private Position position;
    private int tenges;
    private int initialTenges;
    private Rectangle shape;
    private boolean active;
    private int timesEmptied; // Para requisito 12
    
    /**
     * Constructor que crea una tienda con posición y cantidad inicial de tenges.
     * La tienda se inicializa como activa y sin haber sido vaciada.
     * 
     * @param x La posición en el eje X donde se ubicará la tienda
     * @param tenges La cantidad inicial de tenges que tiene la tienda
     */
    public Store(int x, int tenges) {
        this.position = new Position(x);
        this.tenges = tenges;
        this.initialTenges = tenges;
        this.active = true;
        this.shape = null;
        this.timesEmptied = 0;
    }
    
    /**
     * Obtiene la posición de la tienda.
     * 
     * @return La posición de la tienda
     */
    public Position getPosition() {
        return position;
    }
    
    /**
     * Obtiene la cantidad actual de tenges disponibles en la tienda.
     * 
     * @return La cantidad actual de tenges
     */
    public int getTenges() {
        return tenges;
    }
    
    /**
     * Obtiene la cantidad inicial de tenges con la que fue creada la tienda.
     * 
     * @return La cantidad inicial de tenges
     */
    public int getInitialTenges() {
        return initialTenges;
    }
    
    /**
     * NUEVO: Obtiene el número de veces que la tienda ha sido vaciada completamente.
     * Esta es la responsabilidad de la tienda según el requisito 12.
     * 
     * @return El número de veces que la tienda ha sido desocupada
     */
    public int getTimesEmptied() {
        return timesEmptied;
    }
    
    /**
     * Reabastece la tienda con su cantidad inicial de tenges si está activa.
     */
    public void resupply() {
        if (active) {
            tenges = initialTenges;
        }
    }
    
    /**
     * Recolecta todos los tenges de la tienda, dejándola vacía si está activa.
     * Incrementa el contador de veces vaciada.
     */
    public void collect() {
        if (active && tenges > 0) {
            tenges = 0;
            timesEmptied++;
        }
    }
    
    /**
     * Recolecta una cantidad específica de tenges de la tienda.
     * Si se vacía completamente, incrementa el contador.
     * 
     * @param amount La cantidad de tenges que se desea recolectar
     * @return La cantidad real de tenges recolectados
     */
    public int collect(int amount) {
        if (!active) return 0;
        
        int collected = Math.min(tenges, amount);
        tenges -= collected;
        
        // Si quedó en 0, incrementar contador de veces vaciada
        if (tenges == 0 && collected > 0) {
            timesEmptied++;
        }
        
        return collected;
    }
    
    /**
     * Desactiva la tienda y elimina todos sus tenges.
     * Una tienda removida no puede realizar más operaciones.
     */
    public void remove() {
        active = false;
        tenges = 0;
    }
    
    /**
     * Verifica si la tienda está activa y tiene tenges disponibles.
     * 
     * @return true si la tienda está activa y tiene tenges, false en caso contrario
     */
    public boolean isActive() {
        return active && tenges > 0;
    }
    
    /**
     * Verifica si la tienda ha sido removida (desactivada).
     * 
     * @return true si la tienda ha sido removida, false en caso contrario
     */
    public boolean isRemoved() {
        return !active;
    }
    
    /**
     * Verifica si la tienda tiene stock disponible (está activa y tiene tenges).
     * 
     * @return true si la tienda tiene stock disponible, false en caso contrario
     */
    public boolean hasStock() {
        return active && tenges > 0;
    }
    
    /**
     * Obtiene la posición X de la tienda como entero.
     * 
     * @return La coordenada X de la tienda
     */
    public int getPositionX() {
        return position.getX();
    }
    
    /**
     * Verifica si la tienda está vacía.
     * 
     * @return true si la tienda tiene 0 tenges, false en caso contrario
     */
    public boolean isEmpty() {
        return tenges == 0;
    }
    
    /**
     * Reinicia el contador de veces vaciada (útil para reboot).
     */
    public void resetEmptiedCount() {
        timesEmptied = 0;
    }
    
    /**
     * Método para dibujar la tienda en la GUI.
     * Las tiendas vacías deben lucir diferentes (requisito de usabilidad).
     */
    public void draw() {
        // TODO: Implementar representación gráfica
        // Si isEmpty(), cambiar color o apariencia
    }
    
    @Override
    public String toString() {
        return "Store{position=" + position.getX() + 
               ", tenges=" + tenges + ", timesEmptied=" + timesEmptied + "}";
    }
}