/**
 * Representa una tienda en SilkRoad.
 * 
 * @author Buitrago - Garcia
 * @version 2.0
 */
public class Store {
    private int id;
    private Position position;
    private int tenges;
    private int initialTenges;
    private Rectangle shape;
    private boolean active;
    
    /**
     * Constructor que crea una tienda con ID, posición y cantidad inicial de tenges.
     * La tienda se inicializa como activa.
     * 
     * @param id El identificador único de la tienda
     * @param x La posición en el eje X donde se ubicará la tienda
     * @param tenges La cantidad inicial de tenges que tiene la tienda
     */
    public Store(int id, int x, int tenges) {
        this.id = id;
        this.position = new Position(x);
        this.tenges = tenges;
        this.initialTenges = tenges;
        this.active = true;
        this.shape = null;
    }
    
    /**
     * Obtiene el identificador único de la tienda.
     * 
     * @return El ID de la tienda
     */
    public int getId() {
        return id;
    }
    
    /**
     * Obtiene la posición de la tienda.
     * 
     * @return La posición de la tienda
     */
    public Position getPosition() {
        return position;
    }
    
    /**
     * Obtiene la cantidad actual de tenges disponibles en la tienda.
     * 
     * @return La cantidad actual de tenges
     */
    public int getTenges() {
        return tenges;
    }
    
    /**
     * Obtiene la cantidad inicial de tenges con la que fue creada la tienda.
     * 
     * @return La cantidad inicial de tenges
     */
    public int getInitialTenges() {
        return initialTenges;
    }
    
    /**
     * Reabastece la tienda con su cantidad inicial de tenges si está activa.
     */
    public void resupply() {
        if (active) {
            tenges = initialTenges;
        }
    }
    
    /**
     * Recolecta todos los tenges de la tienda, dejándola vacía si está activa.
     */
    public void collect() {
        if (active) {
            tenges = 0;
        }
    }
    
    /**
     * Recolecta una cantidad específica de tenges de la tienda.
     * La cantidad recolectada no puede exceder los tenges disponibles.
     * 
     * @param amount La cantidad de tenges que se desea recolectar
     * @return La cantidad real de tenges recolectados
     */
    public int collect(int amount) {
        if (!active) return 0;
        
        int collected = Math.min(tenges, amount);
        tenges -= collected;
        return collected;
    }
    
    /**
     * Desactiva la tienda y elimina todos sus tenges.
     * Una tienda removida no puede realizar más operaciones.
     */
    public void remove() {
        active = false;
        tenges = 0;
    }
    
    /**
     * Verifica si la tienda está activa y tiene tenges disponibles.
     * 
     * @return true si la tienda está activa y tiene tenges, false en caso contrario
     */
    public boolean isActive() {
    return active && tenges > 0;
    }
    
    /**
     * Verifica si la tienda ha sido removida (desactivada).
     * 
     * @return true si la tienda ha sido removida, false en caso contrario
     */
    public boolean isRemoved() {
    return !active;
    }
    
    /**
     * Verifica si la tienda tiene stock disponible (está activa y tiene tenges).
     * 
     * @return true si la tienda tiene stock disponible, false en caso contrario
     */
    public boolean hasStock() {
        return active && tenges > 0;
    }
    
    /**
     * Obtiene la posición X de la tienda como entero.
     * Útil para algoritmos de pathfinding y cálculos de distancia.
     * 
     * @return La coordenada X de la tienda
     */
    public int getPositionX() {
        return position.getX();
    }
    
    /**
     * Método para dibujar la tienda (implementación pendiente).
     * TODO: Implementar representación gráfica si se desea.
     */
    public void draw() {
    }
    
    /**
     * Compara esta tienda con otro objeto para determinar si son iguales.
     * Dos tiendas son iguales si tienen el mismo ID.
     * 
     * @param obj El objeto a comparar
     * @return true si las tiendas son iguales, false en caso contrario
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Store store = (Store) obj;
        return id == store.id;
    }
    
    /**
     * Genera un código hash para esta tienda basado en su ID.
     * 
     * @return El código hash de la tienda
     */
    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }
}