import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * Clase de prueba colectiva para SilkRoad Ciclo 2.
 * Contribuciones de múltiples equipos para el wiki común.
 * 
 * @author Colectivo Clase POOB
 * @version 2.0
 */
public class SilkRoadCC2Test {
    
    private SilkRoad silkRoad;
    
    @Before
    public void setUp() {
        int[][] days = {
            {10, 20, 30},
            {100, 150, 200},
            {0, 15}
        };
        silkRoad = SilkRoad.create(days);
    }
    
    /**
     * LR - López Rodríguez
     * Verifica que los profits de los robots se muestren correctamente 
     * después de recolectar de múltiples tiendas.
     */
    @Test
    public void showRobotProfitsLRShouldDisplayCorrectProfits() {
        // Arrange
        int[][] days = {
            {1, 3},        // Posiciones tiendas
            {50, 100},     // Tenges tiendas
            {0}            // Robot en posición 0
        };
        SilkRoad sr = SilkRoad.create(days);
        
        // Act
        Robot robot = sr.robots().get(0);
        Store store1 = sr.stores().get(0);
        Store store2 = sr.stores().get(1);
        
        // Mover a tienda 1 (posición 1)
        robot.moveToNewPos(store1.getPositionX());
        robot.collectFromStore(store1);
        
        // Mover a tienda 2 (posición 3)
        robot.moveToNewPos(store2.getPositionX());
        robot.collectFromStore(store2);
        
        // Assert
        assertEquals(150, robot.getCollectedTenges());
        
        // Verificar profits por movimiento
        int[] profits = robot.getProfitsPerMove();
        assertEquals(3, profits.length); // [0, 50, 100]
        assertEquals(0, profits[0]);     // Inicial
        assertEquals(50, profits[1]);    // Primer movimiento
        assertEquals(100, profits[2]);   // Segundo movimiento
    }
    
    /**
     * LR - López Rodríguez
     * Verifica que el profit total se calcule correctamente 
     * sumando los tenges de todos los robots.
     */
    @Test
    public void profitLRShouldCalculateTotalTengesFromAllRobots() {
        // Arrange
        int[][] days = {
            {1, 5},        // Posiciones tiendas
            {100, 200},    // Tenges tiendas
            {0, 6}         // Dos robots
        };
        SilkRoad sr = SilkRoad.create(days);
        
        // Act
        Robot robot0 = sr.robots().get(0);
        Robot robot1 = sr.robots().get(1);
        
        // Mover robot 0 a tienda en posición 1
        robot0.moveToNewPos(1);
        robot0.collectFromStore(sr.stores().get(0));
        
        // Mover robot 1 a tienda en posición 5
        robot1.moveToNewPos(5);
        robot1.collectFromStore(sr.stores().get(1));
        
        int totalProfit = robot0.getCollectedTenges() + robot1.getCollectedTenges();
        
        // Assert
        assertTrue(totalProfit >= 0);
        assertEquals(300, totalProfit); // 100 + 200
    }
    
    /**
     * Autor desconocido
     * Verifica que moveRobots no mueva cuando no hay movimiento beneficioso.
     */
    @Test
    public void shouldNotMoveRobotWhenNoGoodMoveAvailable() {
        // Arrange
        int[][] days = {
            {100},         // Tienda muy lejos
            {10},          // Pocos tenges (profit negativo)
            {0}            // Robot en 0
        };
        SilkRoad sr = SilkRoad.create(days);
        
        // Act
        sr.moveRobots();
        
        // Assert
        Robot robot = sr.robots().get(0);
        assertEquals(0, robot.getPosition().getX()); // No se movió
        assertEquals(0, robot.getCollectedTenges());  // No recolectó
        
        // Verificar que sigue válido el sistema
        assertTrue(sr.ok());
    }
    
    /**
     * GL - García López
     * Verifica que profitPerMove() registre correctamente 
     * las ganancias en cada movimiento del robot.
     */
    @Test
    public void testGLprofitPerMoveShouldTrackRobotProfitsPerMove() {
        // Arrange
        int[][] days = {
            {10, 20},      // Dos tiendas
            {30, 40},      // Con tenges
            {5}            // Robot en posición 5
        };
        SilkRoad sr = SilkRoad.create(days);
        
        // Act - Primer movimiento automático
        sr.moveRobots();
        
        // Reabastecer tiendas para segundo movimiento
        sr.resupply();
        
        // Segundo movimiento automático
        sr.moveRobots();
        
        int[][] profits = sr.profitPerMove();
        
        // Assert
        // Validar que hay un registro para el robot
        assertEquals(1, profits.length);
        
        // Debe tener al menos 3 entradas: inicial + 2 movimientos
        assertTrue(profits[0].length >= 3);
        
        // El primer profit debe ser 0 (inicial)
        assertEquals(0, profits[0][0]);
        
        // Los movimientos deben tener profit > 0 si recolectaron
        assertTrue("Primer movimiento debe tener profit", profits[0][1] > 0);
        
        System.out.println("Ganancias registradas por el robot: " 
                        + profits[0][1] + ", " + profits[0][2]);
    }
}