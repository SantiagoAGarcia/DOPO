import java.util.*;

/**
 * Resuelve el problema de la maratón The Silk Road with Robots.
 * Calcula la máxima utilidad diaria asignando óptimamente tiendas a robots.
 * 
 * REQUISITO 14: Debe solucionar el problema de la maratón
 * 
 * Problema: Dado un día con:
 * - Posiciones de tiendas y sus tenges
 * - Posiciones de robots
 * Encontrar la asignación que maximiza: suma(tenges_tienda - distancia(robot, tienda))
 * 
 * Algoritmo: Greedy óptimo
 * 1. Calcular profit para cada par (robot, tienda)
 * 2. Ordenar por profit descendente
 * 3. Seleccionar asignaciones maximizando profit total
 * 4. Garantizar: cada robot a máximo 1 tienda, cada tienda a máximo 1 robot
 * 
 * @author Buitrago - Garcia
 * @version 1.0 - Ciclo 3
 */
public class SilkRoadSolver {
    private int[] storePositions;
    private int[] storeTenges;
    private int[] robotPositions;
    private int maxProfit;
    private List<Assignment> optimalAssignments;
    private MessageHandler messageHandler;
    
    /**
     * Estructura para representar una asignación robot-tienda.
     */
    public static class Assignment {
        public int robotIndex;
        public int storeIndex;
        public int profit;
        
        public Assignment(int robotIndex, int storeIndex, int profit) {
            this.robotIndex = robotIndex;
            this.storeIndex = storeIndex;
            this.profit = profit;
        }
        
        @Override
        public String toString() {
            return "Robot[" + robotIndex + "] -> Store[" + storeIndex + 
                   "] (profit: " + profit + ")";
        }
    }
    
    /**
     * Constructor que inicializa el solver con los datos de un día.
     * 
     * @param storePositions Posiciones de las tiendas
     * @param storeTenges Tenges de cada tienda
     * @param robotPositions Posiciones de los robots
     */
    public SilkRoadSolver(int[] storePositions, int[] storeTenges, int[] robotPositions) {
        this.storePositions = storePositions;
        this.storeTenges = storeTenges;
        this.robotPositions = robotPositions;
        this.maxProfit = 0;
        this.optimalAssignments = new ArrayList<>();
        this.messageHandler = new MessageHandler(true);
    }
    
    /**
     * REQUISITO 14: Resuelve el problema calculando la máxima utilidad diaria.
     * Usa algoritmo greedy óptimo:
     * 1. Calcula profit para cada par (robot, tienda)
     * 2. Selecciona asignaciones en orden descendente de profit
     * 3. Garantiza máxima utilidad respetando restricciones
     * 
     * @return La máxima utilidad que se puede obtener
     */
    public int solve() {
        if (storePositions == null || robotPositions == null || 
            storePositions.length == 0 || robotPositions.length == 0) {
            messageHandler.showMessage("Error: Entrada inválida para resolver.");
            return 0;
        }
        
        List<ProfitAssignment> possibleAssignments = new ArrayList<>();
        
        for (int r = 0; r < robotPositions.length; r++) {
            for (int s = 0; s < storePositions.length; s++) {
                int distance = Math.abs(robotPositions[r] - storePositions[s]);
                int profit = storeTenges[s] - distance;
                possibleAssignments.add(new ProfitAssignment(r, s, profit));
            }
        }
        
        possibleAssignments.sort((a, b) -> Integer.compare(b.profit, a.profit));
        
        Set<Integer> usedRobots = new HashSet<>();
        Set<Integer> usedStores = new HashSet<>();
        optimalAssignments.clear();
        maxProfit = 0;
        
        for (ProfitAssignment pa : possibleAssignments) {
            if (!usedRobots.contains(pa.robotIndex) && 
                !usedStores.contains(pa.storeIndex) && 
                pa.profit > 0) {
                
                optimalAssignments.add(new Assignment(pa.robotIndex, pa.storeIndex, pa.profit));
                usedRobots.add(pa.robotIndex);
                usedStores.add(pa.storeIndex);
                maxProfit += pa.profit;
            }
        }
        
        return maxProfit;
    }
    
    /**
     * Obtiene la máxima utilidad calculada.
     * 
     * @return El máximo profit
     */
    public int getMaxProfit() {
        return maxProfit;
    }
    
    /**
     * Obtiene las asignaciones óptimas.
     * 
     * @return Lista de asignaciones robot-tienda
     */
    public List<Assignment> getOptimalAssignments() {
        return new ArrayList<>(optimalAssignments);
    }
    
    /**
     * Obtiene la solución como matriz para retornar.
     * Cada fila contiene: [robotIndex, storeIndex, profit]
     * 
     * @return Matriz con las asignaciones
     */
    public int[][] getSolutionAsMatrix() {
        int[][] solution = new int[optimalAssignments.size()][3];
        
        for (int i = 0; i < optimalAssignments.size(); i++) {
            Assignment a = optimalAssignments.get(i);
            solution[i][0] = a.robotIndex;
            solution[i][1] = a.storeIndex;
            solution[i][2] = a.profit;
        }
        
        return solution;
    }
    
    /**
     * Muestra la solución en formato legible.
     */
    public void printSolution() {
        messageHandler.showMessage("\n=== SOLUCIÓN DEL PROBLEMA ===");
        messageHandler.showMessage("Máxima utilidad: " + maxProfit);
        messageHandler.showMessage("\nAsignaciones:");
        
        for (Assignment a : optimalAssignments) {
            messageHandler.showMessage(a.toString());
        }
    }
    
    /**
     * Establece la visibilidad de mensajes.
     * 
     * @param visible true para mostrar mensajes
     */
    public void setVisible(boolean visible) {
        messageHandler.setVisible(visible);
    }
    
    /**
     * Clase interna para gestionar asignaciones con profit.
     */
    private static class ProfitAssignment {
        int robotIndex;
        int storeIndex;
        int profit;
        
        ProfitAssignment(int robotIndex, int storeIndex, int profit) {
            this.robotIndex = robotIndex;
            this.storeIndex = storeIndex;
            this.profit = profit;
        }
    }
}