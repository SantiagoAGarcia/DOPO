/**
 * Maneja los días de la simulación SilkRoad.
 * 
 * @author Buitrago - Garcia
 * @version 2.0
 */
public class DayManager {
    private int currentDay;
    private int totalDays;
    
    /**
     * Constructor que inicializa el manejador de días con el número total de días de simulación.
     * El día actual se inicializa en 1.
     * 
     * @param totalDays El número total de días que durará la simulación
     */
    public DayManager(int totalDays) {
        this.currentDay = 1;
        this.totalDays = totalDays;
    }
    
    /**
     * Avanza al siguiente día de la simulación.
     * Incrementa el contador de día actual en 1.
     */
    public void nextDay() {
        currentDay++;
    }
    
    /**
     * Obtiene el día actual de la simulación.
     * 
     * @return El número del día actual
     */
    public int getCurrentDay() {
        return currentDay;
    }
    
    /**
     * Verifica si la simulación ha terminado.
     * La simulación termina cuando el día actual supera el total de días.
     * 
     * @return true si la simulación ha terminado, false en caso contrario
     */
    public boolean isFinished() {
        return currentDay > totalDays;
    }
}