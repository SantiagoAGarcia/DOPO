import java.util.*;

/**
 * Calculadora de profit para análisis en SilkRoad.
 * Calcula el profit máximo que PODRÍA obtenerse en la situación actual.
 * 
 * NOTA: Esta clase es SOLO para análisis y consultas.
 * Para RESOLVER el problema de la maratón, usar SilkRoadSolver.
 * Para SIMULAR, usar SilkRoad.simulate().
 * 
 * @author Buitrago - Garcia
 * @version 3.0 - Ciclo 3
 */
public class ProfitCalculator {
    private Robot bestRobot;
    private Store bestStore;
    private int maxProfit;
    
    /**
     * Constructor por defecto que inicializa la calculadora.
     * Establece el profit máximo en 0 y las referencias del mejor robot y tienda como null.
     */
    public ProfitCalculator() {
        maxProfit = 0;
        bestRobot = null;
        bestStore = null;
    }
    
    /**
     * Calcula el profit máximo total analizando la situación actual.
     * Asigna cada tienda al robot más rentable.
     * 
     * PROPÓSITO: Análisis de la simulación actual
     * NO es resolución del problema - es solo información para el usuario.
     * 
     * @param robots Lista de robots en la simulación
     * @param stores Lista de tiendas en la simulación
     * @return El profit máximo potencial en la situación actual
     */
    public int calculateMaxProfit(List<Robot> robots, List<Store> stores) {
        maxProfit = 0;
        bestRobot = null;
        bestStore = null;
        
        if (robots.isEmpty() || stores.isEmpty()) {
            return maxProfit;
        }
        
        for (Store s : stores) {
            if (s.isRemoved()) continue;
            
            int bestProfit = 0;
            Robot chosen = null;
            
            for (Robot r : robots) {
                if (!r.isActive()) continue;
                
                int distance = Math.abs(r.getPosition().getX() - s.getPosition().getX());
                int profit = s.getTenges() - distance;
                
                if (profit > bestProfit) {
                    bestProfit = profit;
                    chosen = r;
                }
            }
            
            if (chosen != null && bestProfit > 0) {
                maxProfit += bestProfit;
                bestRobot = chosen;
                bestStore = s;
            }
        }
        
        return maxProfit;
    }
    
    /**
     * Retorna el profit máximo total calculado.
     * 
     * @return El profit máximo potencial obtenido en la última ejecución
     */
    public int getMaxProfit() {
        return maxProfit;
    }
    
    /**
     * Retorna el robot que participó en la última asignación más rentable.
     * 
     * @return El último robot que generó el mejor profit, o null si no hay asignaciones
     */
    public Robot getBestRobot() {
        return bestRobot;
    }
    
    /**
     * Retorna la tienda que participó en la última asignación más rentable.
     * 
     * @return La última tienda que generó el mejor profit, o null si no hay asignaciones
     */
    public Store getBestStore() {
        return bestStore;
    }
}