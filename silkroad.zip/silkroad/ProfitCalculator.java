import java.util.*;
/**
 * Calculadora de profit máximo en SilkRoad.
 * Asigna cada tienda al robot que le dé mayor beneficio.
 * 
 * El profit de una tienda se calcula como:
 *     tenges - distancia(robot, tienda)
 * 
 * Si no hay robots o tiendas, el profit es 0.
 * 
 * Mantiene el profit total y referencias
 * al último robot y tienda que dieron mayor beneficio.
 * 
 * @author Buitrago - Garcia
 * @version 2.2
 */
public class ProfitCalculator {
    private Robot bestRobot;
    private Store bestStore;
    private int maxProfit;
    
    /**
     * Constructor por defecto que inicializa la calculadora.
     * Establece el profit máximo en 0 y las referencias del mejor robot y tienda como null.
     */
    public ProfitCalculator() {
        maxProfit = 0;
        bestRobot = null;
        bestStore = null;
    }
    
    /**
     * Calcula el profit máximo total asignando cada tienda al robot más rentable.
     * 
     * @param robots Lista de robots disponibles
     * @param stores Lista de tiendas a evaluar
     * @return El profit máximo total obtenido
     */
    public int calculateMaxProfit(List<Robot> robots, List<Store> stores) {
        maxProfit = 0;
        if (robots.isEmpty() || stores.isEmpty()) {
            return maxProfit;
        }
        
        for (Store s : stores) {
            int bestProfit = 0;
            Robot chosen = null;
            
            for (Robot r : robots) {
                int distancia = Math.abs(r.getPosition().getX() - s.getPosition().getX());
                int profit = s.getTenges() - distancia;
                
                if (profit > bestProfit) {
                    bestProfit = profit;
                    chosen = r;
                }
            }
            
            if (chosen != null) {
                maxProfit += bestProfit;
                bestRobot = chosen;
                bestStore = s;
            }
        }
        
        return maxProfit;
    }
    
    /**
     * Retorna el profit máximo total calculado.
     * 
     * @return El profit máximo total obtenido en la última ejecución
     */
    public int getMaxProfit() {
        return maxProfit;
    }
    
    /**
     * Retorna el robot que participó en la última asignación más rentable.
     * 
     * @return El último robot que generó el mejor profit, o null si no hay asignaciones
     */
    public Robot getBestRobot() {
        return bestRobot;
    }
    
    /**
     * Retorna la tienda que participó en la última asignación más rentable.
     * 
     * @return La última tienda que generó el mejor profit, o null si no hay asignaciones
     */
    public Store getBestStore() {
        return bestStore;
    }
}