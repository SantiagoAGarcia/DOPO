import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.List;
import java.util.Set;
import java.util.HashSet;

/**
 * Pruebas de unidad para SilkRoad Ciclo 3 (Contest).
 * Cubre los requisitos 14 y 15.
 * 
 * Requisito 14: Debe solucionar el problema de la maratón
 * Requisito 15: Debe simular la solución
 * 
 * @author Buitrago - Garcia
 * @version 1.0
 */
public class SilkRoadContestTest {
    
    private SilkRoadSolver solver;
    private SilkRoad silkRoad;
    
    @Before
    public void setUp() {
        int[] storePos = {10, 20, 30};
        int[] storeTenges = {100, 150, 200};
        int[] robotPos = {0, 15};
        
        solver = new SilkRoadSolver(storePos, storeTenges, robotPos);
        
        int[][] days = {storePos, storeTenges, robotPos};
        silkRoad = SilkRoad.create(days);
    }
    
    // ===============================================================
    // REQUISITO 14: PRUEBAS PARA solve()
    // ===============================================================
    
    /**
     * REQUISITO 14: Debe solucionar el problema de la maratón.
     * Verifica que solve() calcula correctamente la máxima utilidad.
     */
    @Test
    public void shouldSolveMarathonProblem() {
        // Arrange
        // Robot 0 en 0: profit tienda 0 = 100-10=90, tienda 1 = 150-20=130, tienda 2 = 200-30=170
        // Robot 1 en 15: profit tienda 0 = 100-15=85, tienda 1 = 150-5=145, tienda 2 = 200-15=185
        // Óptimo: Robot 1 -> Tienda 2 (profit 185) + Robot 0 -> Tienda 1 (profit 130) = 315
        
        // Act
        int maxProfit = solver.solve();
        
        // Assert
        assertEquals(315, maxProfit);
    }
    
    /**
     * REQUISITO 14: Verifica que las asignaciones sean correctas.
     */
    @Test
    public void shouldReturnOptimalAssignments() {
        // Arrange
        solver.solve();
        
        // Act
        List<SilkRoadSolver.Assignment> assignments = solver.getOptimalAssignments();
        
        // Assert
        assertEquals(2, assignments.size());
        
        Set<Integer> robots = new HashSet<>();
        Set<Integer> stores = new HashSet<>();
        for (SilkRoadSolver.Assignment a : assignments) {
            robots.add(a.robotIndex);
            stores.add(a.storeIndex);
        }
        assertEquals(2, robots.size());
        assertEquals(2, stores.size());
    }
    
    /**
     * REQUISITO 14: No debe asignar tiendas con profit negativo.
     */
    @Test
    public void shouldNotAssignNegativeProfit() {
        // Arrange
        int[] storePos = {100};
        int[] storeT = {10};
        int[] robotPos = {0};
        SilkRoadSolver s = new SilkRoadSolver(storePos, storeT, robotPos);
        
        // Act
        int profit = s.solve();
        
        // Assert
        assertEquals(0, profit);
        assertEquals(0, s.getOptimalAssignments().size());
    }
    
    /**
     * REQUISITO 14: Cada robot se debe asignar a lo más una tienda.
     */
    @Test
    public void shouldAssignEachRobotAtMostOnce() {
        // Arrange
        solver.solve();
        
        // Act
        List<SilkRoadSolver.Assignment> assignments = solver.getOptimalAssignments();
        
        // Assert
        Set<Integer> robotsSeen = new HashSet<>();
        for (SilkRoadSolver.Assignment a : assignments) {
            assertFalse("Robot " + a.robotIndex + " asignado múltiples veces", 
                robotsSeen.contains(a.robotIndex));
            robotsSeen.add(a.robotIndex);
        }
    }
    
    /**
     * REQUISITO 14: Cada tienda se debe asignar a lo más un robot.
     */
    @Test
    public void shouldAssignEachStoreAtMostOnce() {
        // Arrange
        solver.solve();
        
        // Act
        List<SilkRoadSolver.Assignment> assignments = solver.getOptimalAssignments();
        
        // Assert
        Set<Integer> storesSeen = new HashSet<>();
        for (SilkRoadSolver.Assignment a : assignments) {
            assertFalse("Tienda " + a.storeIndex + " asignada múltiples veces", 
                storesSeen.contains(a.storeIndex));
            storesSeen.add(a.storeIndex);
        }
    }
    
    /**
     * REQUISITO 14: Debe resolver entrada sin robots.
     */
    @Test
    public void shouldHandleEmptyRobots() {
        // Arrange
        int[] storePos = {10, 20};
        int[] storeT = {100, 150};
        int[] robotPos = {};
        SilkRoadSolver s = new SilkRoadSolver(storePos, storeT, robotPos);
        
        // Act
        int profit = s.solve();
        
        // Assert
        assertEquals(0, profit);
    }
    
    /**
     * REQUISITO 14: Debe resolver entrada sin tiendas.
     */
    @Test
    public void shouldHandleEmptyStores() {
        // Arrange
        int[] storePos = {};
        int[] storeT = {};
        int[] robotPos = {0, 10};
        SilkRoadSolver s = new SilkRoadSolver(storePos, storeT, robotPos);
        
        // Act
        int profit = s.solve();
        
        // Assert
        assertEquals(0, profit);
    }
    
    /**
     * REQUISITO 14: Matriz de solución debe tener formato correcto.
     */
    @Test
    public void shouldReturnSolutionMatrixWithCorrectFormat() {
        // Arrange
        solver.solve();
        
        // Act
        int[][] matrix = solver.getSolutionAsMatrix();
        
        // Assert
        for (int[] row : matrix) {
            assertEquals(3, row.length);
            assertTrue(row[0] >= 0);
            assertTrue(row[1] >= 0);
            assertTrue(row[2] > 0);
        }
    }
    
    /**
     * REQUISITO 14: Caso simple con una tienda y un robot.
     */
    @Test
    public void shouldSolveSingleRobotSingleStore() {
        // Arrange
        int[] storePos = {20};
        int[] storeT = {100};
        int[] robotPos = {0};
        SilkRoadSolver s = new SilkRoadSolver(storePos, storeT, robotPos);
        
        // Act
        int profit = s.solve();
        
        // Assert
        // profit = 100 - 20 = 80
        assertEquals(80, profit);
    }
    
    // ===============================================================
    // REQUISITO 15: PRUEBAS PARA simulate()
    // ===============================================================
    
    /**
     * REQUISITO 15: Debe simular la solución correctamente.
     */
    @Test
    public void shouldSimulateSolutionCorrectly() {
        // Arrange
        int[][] days = {
            {10, 20, 30},
            {100, 150, 200},
            {0, 15}
        };
        SilkRoad sr = SilkRoad.create(days);
        
        int[] storePos = {10, 20, 30};
        int[] storeT = {100, 150, 200};
        int[] robotPos = {0, 15};
        SilkRoadSolver s = new SilkRoadSolver(storePos, storeT, robotPos);
        s.solve();
        
        // Act
        sr.simulate(s);
        
        // Assert
        int total = 0;
        for (Robot r : sr.robots()) {
            total += r.getCollectedTenges();
        }
        assertTrue(total > 0);
    }
    
    /**
     * REQUISITO 15: Debe actualizar profits durante simulación.
     */
    @Test
    public void shouldUpdateProfitsDuringSimulation() {
        // Arrange
        int[][] days = {{10}, {100}, {0}};
        SilkRoad sr = SilkRoad.create(days);
        
        int[] storePos = {10};
        int[] storeT = {100};
        int[] robotPos = {0};
        SilkRoadSolver s = new SilkRoadSolver(storePos, storeT, robotPos);
        s.solve();
        
        // Act
        sr.simulate(s);
        int[][] profits = sr.profitPerMove();
        
        // Assert
        assertEquals(2, profits[0].length);
        assertEquals(0, profits[0][0]);
        assertEquals(100, profits[0][1]);
    }
    
    /**
     * REQUISITO 15: Simulación con solver nulo no debe crashear.
     */
    @Test
    public void shouldHandleNullSolver() {
        // Arrange
        int[][] days = {{10}, {100}, {0}};
        SilkRoad sr = SilkRoad.create(days);
        
        // Act & Assert - No debe lanzar excepción
        sr.simulate(null);
        assertTrue(sr.ok());
    }
    
    /**
     * REQUISITO 15: Los robots deben llegar a las tiendas correctas.
     */
    @Test
    public void shouldRobotsMoveToPrescribedStores() {
        // Arrange
        int[][] days = {{10, 30}, {100, 200}, {0}};
        SilkRoad sr = SilkRoad.create(days);
        
        int[] storePos = {10, 30};
        int[] storeT = {100, 200};
        int[] robotPos = {0};
        SilkRoadSolver s = new SilkRoadSolver(storePos, storeT, robotPos);
        s.solve();
        
        // Act
        sr.simulate(s);
        
        // Assert
        Robot robot = sr.robots().get(0);
        assertEquals(30, robot.getPosition().getX());
    }
    
    /**
     * VALIDACIÓN: La suma de profits debe ser correcta.
     */
    @Test
    public void shouldValidateProfitCalculation() {
        // Arrange
        int[] storePos = {10, 20};
        int[] storeT = {100, 80};
        int[] robotPos = {5, 25};
        SilkRoadSolver s = new SilkRoadSolver(storePos, storeT, robotPos);
        
        // Act
        int profit = s.solve();
        
        // Assert
        List<SilkRoadSolver.Assignment> assignments = s.getOptimalAssignments();
        int calculatedProfit = 0;
        for (SilkRoadSolver.Assignment a : assignments) {
            calculatedProfit += a.profit;
        }
        assertEquals(profit, calculatedProfit);
    }
}