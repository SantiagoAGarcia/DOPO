import java.util.*;

/**
 * Clase principal de la simulación SilkRoad extendida.
 * Administra robots, tiendas y el flujo de la simulación.
 * Trabaja directamente con referencias de objetos, sin IDs.
 * 
 * CICLO 2: Requisitos 10-13
 * CICLO 3: Requisitos 14-15 (Se agregan solve y simulate)
 * 
 * @author Buitrago - Garcia
 * @version 3.0 - Ciclo 3
 */
public class SilkRoad {
    private List<Store> stores;
    private List<Robot> robots;
    private ProfitBar profitBar;
    private DayManager dayManager;
    private MessageHandler messageHandler;
    private boolean ok;
    
    /**
     * Constructor privado - usar create() para instanciar.
     */
    private SilkRoad() {
        stores = new ArrayList<>();
        robots = new ArrayList<>();
        profitBar = new ProfitBar(0);
        dayManager = null;
        messageHandler = new MessageHandler(true);
        ok = true;
    }
    
    /**
     * REQUISITO 10: Crea una ruta de seda con la entrada del problema de la maratón.
     * 
     * @param days Matriz con configuración inicial
     * @return Nueva instancia de SilkRoad configurada
     */
    public static SilkRoad create(int[][] days) {
        SilkRoad silkRoad = new SilkRoad();
        
        if (days == null || days.length < 3) {
            silkRoad.messageHandler.showMessage("Error: Entrada inválida. Se requieren al menos 3 vectores.");
            silkRoad.ok = false;
            return silkRoad;
        }
        
        int[] storePositions = days[0];
        int[] storeTenges = days[1];
        int[] robotPositions = days[2];
        
        if (storePositions.length != storeTenges.length) {
            silkRoad.messageHandler.showMessage("Error: Número de tiendas y tenges no coinciden.");
            silkRoad.ok = false;
            return silkRoad;
        }
        
        for (int i = 0; i < storePositions.length; i++) {
            Store store = new Store(storePositions[i], storeTenges[i]);
            silkRoad.stores.add(store);
        }
        
        for (int i = 0; i < robotPositions.length; i++) {
            Robot robot = new Robot(robotPositions[i]);
            silkRoad.robots.add(robot);
        }
        
        int totalDays = Math.max(1, days.length - 3);
        silkRoad.dayManager = new DayManager(totalDays);
        
        silkRoad.messageHandler.showMessage("SilkRoad creado exitosamente:");
        silkRoad.messageHandler.showMessage("- Tiendas: " + storePositions.length);
        silkRoad.messageHandler.showMessage("- Robots: " + robotPositions.length);
        silkRoad.messageHandler.showMessage("- Días de simulación: " + totalDays);
        
        return silkRoad;
    }
    
    /**
     * REQUISITO 11: Mueve todos los robots automáticamente buscando maximizar la ganancia.
     * CICLO 2: Cada robot se mueve a la tienda más rentable considerando:
     * profit = tenges_tienda - distancia(robot, tienda)
     * 
     * NOTA: Este método es un SIMULADOR greedy automático.
     * Para resolver el problema de la maratón, usar SilkRoadSolver.solve() + simulate().
     */
    public void moveRobots() {
        if (robots.isEmpty() || stores.isEmpty()) {
            messageHandler.showMessage("No hay robots o tiendas para mover.");
            return;
        }
        
        List<Store> availableStores = new ArrayList<>();
        for (Store s : stores) {
            if (s.isActive() && s.hasStock()) {
                availableStores.add(s);
            }
        }
        
        for (Robot robot : robots) {
            if (!robot.isActive()) continue;
            
            Store bestStore = null;
            int maxProfit = Integer.MIN_VALUE;
            
            for (Store store : availableStores) {
                int distance = Math.abs(robot.getPosition().getX() - store.getPositionX());
                int profit = store.getTenges() - distance;
                
                if (profit > maxProfit) {
                    maxProfit = profit;
                    bestStore = store;
                }
            }
            
            if (bestStore != null && maxProfit > 0) {
                int oldPos = robot.getPosition().getX();
                robot.moveToNewPos(bestStore.getPositionX());
                int collected = robot.collectFromStore(bestStore);
                
                messageHandler.showMessage("Robot en " + oldPos + 
                    " se movió a " + bestStore.getPositionX() + 
                    " y recolectó " + collected + " tenges (profit: " + maxProfit + ")");
                
                if (bestStore.isEmpty()) {
                    availableStores.remove(bestStore);
                }
            } else {
                robot.recordProfit(0);
                messageHandler.showMessage("Robot en " + robot.getPosition().getX() + 
                    " no encontró movimiento rentable.");
            }
        }
    }
    
    /**
     * REQUISITO 12: Consulta el número de veces que cada tienda ha sido desocupada.
     * 
     * @return Matriz donde cada fila corresponde a una tienda [índice, vecesDesocupada]
     */
    public int[][] emptiedStores() {
        int[][] result = new int[stores.size()][2];
        
        for (int i = 0; i < stores.size(); i++) {
            Store store = stores.get(i);
            result[i][0] = i;
            result[i][1] = store.getTimesEmptied();
        }
        
        return result;
    }
    
    /**
     * REQUISITO 13: Consulta las ganancias que ha logrado cada robot en cada movimiento.
     * 
     * @return Matriz donde cada fila corresponde a un robot y contiene sus profits por movimiento
     */
    public int[][] profitPerMove() {
        int[][] result = new int[robots.size()][];
        
        for (int i = 0; i < robots.size(); i++) {
            Robot robot = robots.get(i);
            result[i] = robot.getProfitsPerMove();
        }
        
        return result;
    }
    
    /**
     * REQUISITO IMPLÍCITO: Extensión - Consulta general.
     * Muestra estadísticas usando los métodos de requisitos 12 y 13.
     */
    public void consult() {
        messageHandler.showMessage("\n=== CONSULTA DE ESTADÍSTICAS ===");
        messageHandler.showMessage("Día actual: " + dayManager.getCurrentDay());
        
        messageHandler.showMessage("\n--- Tiendas Desocupadas ---");
        int[][] emptied = emptiedStores();
        for (int[] data : emptied) {
            messageHandler.showMessage("Tienda " + data[0] + ": desocupada " + data[1] + " veces");
        }
        
        messageHandler.showMessage("\n--- Profits por Movimiento ---");
        int[][] profits = profitPerMove();
        for (int i = 0; i < profits.length; i++) {
            StringBuilder sb = new StringBuilder("Robot " + i + ": [");
            for (int j = 0; j < profits[i].length; j++) {
                sb.append(profits[i][j]);
                if (j < profits[i].length - 1) sb.append(", ");
            }
            sb.append("]");
            messageHandler.showMessage(sb.toString());
        }
        
        Robot bestRobot = getBestRobot();
        if (bestRobot != null) {
            int robotIndex = robots.indexOf(bestRobot);
            messageHandler.showMessage("\nMejor robot: Robot " + robotIndex + 
                " con " + bestRobot.getCollectedTenges() + " tenges");
        }
    }
    
    /**
     * REQUISITO 15: Simula la solución óptima del problema de la maratón.
     * Ejecuta los movimientos según la solución calculada por SilkRoadSolver.
     * 
     * Diferencia con moveRobots():
     * - moveRobots() es un simulador greedy automático (Ciclo 2)
     * - simulate() es para ejecutar una solución específica (Ciclo 3)
     * 
     * @param solver El solver que contiene la solución del problema
     */
    public void simulate(SilkRoadSolver solver) {
        if (solver == null) {
            messageHandler.showMessage("Error: Solver es nulo.");
            return;
        }
        
        if (robots.isEmpty() || stores.isEmpty()) {
            messageHandler.showMessage("No hay robots o tiendas para simular.");
            return;
        }
        
        messageHandler.showMessage("\n=== SIMULANDO SOLUCIÓN ===");
        
        List<SilkRoadSolver.Assignment> assignments = solver.getOptimalAssignments();
        
        for (SilkRoadSolver.Assignment assignment : assignments) {
            int robotIdx = assignment.robotIndex;
            int storeIdx = assignment.storeIndex;
            
            if (robotIdx >= robots.size() || storeIdx >= stores.size()) {
                messageHandler.showMessage("Error: Índices fuera de rango.");
                continue;
            }
            
            Robot robot = robots.get(robotIdx);
            Store store = stores.get(storeIdx);
            
            if (!robot.isActive() || !store.isActive()) {
                messageHandler.showMessage("Robot o tienda no está activo.");
                continue;
            }
            
            int oldPos = robot.getPosition().getX();
            robot.moveToNewPos(store.getPositionX());
            int collected = robot.collectFromStore(store);
            
            messageHandler.showMessage("Robot " + robotIdx + " se movió de " + oldPos + 
                " a " + store.getPositionX() + " y recolectó " + collected + 
                " tenges (profit esperado: " + assignment.profit + ")");
        }
        
        messageHandler.showMessage("\n=== SIMULACIÓN COMPLETADA ===");
        messageHandler.showMessage("Utilidad total obtenida: " + solver.getMaxProfit());
    }
    
    /**
     * Encuentra el robot con mayor ganancia acumulada.
     * PRIVADO - no debe ser público.
     */
    private Robot getBestRobot() {
        if (robots.isEmpty()) return null;
        
        Robot best = robots.get(0);
        for (Robot r : robots) {
            if (r.getCollectedTenges() > best.getCollectedTenges()) {
                best = r;
            }
        }
        return best;
    }
    
    /**
     * Encuentra la tienda con más tenges disponibles.
     * PRIVADO - no debe ser público.
     */
    private Store getBestStore() {
        if (stores.isEmpty()) return null;
        
        Store best = stores.get(0);
        for (Store s : stores) {
            if (s.getTenges() > best.getTenges()) {
                best = s;
            }
        }
        return best;
    }
    
    public Store placeStore(int position, int tenges) {
        Store store = new Store(position, tenges);
        stores.add(store);
        return store;
    }
    
    public void removeStore(Store store) {
        if (stores.remove(store)) {
            messageHandler.showMessage("Tienda removida.");
        }
    }
    
    public void resupply() {
        for (Store s : stores) {
            s.resupply();
        }
        messageHandler.showMessage("Todas las tiendas reabastecidas.");
    }
    
    public Robot placeRobot(int position) {
        Robot robot = new Robot(position);
        robots.add(robot);
        return robot;
    }
    
    public void removeRobot(Robot robot) {
        if (robots.remove(robot)) {
            messageHandler.showMessage("Robot removido.");
        }
    }
    
    public void reboot() {
        for (Robot r : robots) {
            r.reset();
        }
        for (Store s : stores) {
            s.resupply();
            s.resetEmptiedCount();
        }
        profitBar.reset();
        if (dayManager != null) {
            dayManager = new DayManager(dayManager.getCurrentDay());
        }
        ok = true;
        messageHandler.showMessage("Sistema reiniciado.");
    }
    
    public void rebootRobot(Robot robot) {
        if (robots.contains(robot)) {
            robot.reset();
            messageHandler.showMessage("Robot reiniciado.");
        }
    }
    
    public void nextDay() {
        if (dayManager != null) {
            dayManager.nextDay();
            messageHandler.showMessage("Avanzando al día " + dayManager.getCurrentDay());
            
            if (dayManager.isFinished()) {
                finish();
            }
        }
    }
    
    public List<Robot> robots() {
        return new ArrayList<>(robots);
    }
    
    public List<Store> stores() {
        return new ArrayList<>(stores);
    }
    
    public void makeVisible() {
        messageHandler.setVisible(true);
    }
    
    public void makeInvisible() {
        messageHandler.setVisible(false);
    }
    
    public void finish() {
        messageHandler.showMessage("\n=== SIMULACIÓN FINALIZADA ===");
        messageHandler.showMessage("Estadísticas finales:");
        
        messageHandler.showMessage("\n--- Robots ---");
        for (int i = 0; i < robots.size(); i++) {
            messageHandler.showMessage("Robot " + i + ": " + robots.get(i).toString());
        }
        
        messageHandler.showMessage("\n--- Tiendas ---");
        for (int i = 0; i < stores.size(); i++) {
            messageHandler.showMessage("Tienda " + i + ": " + stores.get(i).toString());
        }
        
        ok = false;
    }
    
    public boolean ok() {
        return ok;
    }
}