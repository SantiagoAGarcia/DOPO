import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.List;
import java.util.Set;
import java.util.HashSet;

/**
 * Suite completa de pruebas para SilkRoad - Ciclos 1, 2 y 3.
 * Modo invisible para automatización.
 * 
 * Ciclo 1: Estructura base
 * Ciclo 2: Requisitos 10-13
 * Ciclo 3: Requisitos 14-15
 * 
 * @author Buitrago - Garcia
 * @version 3.0
 */
public class SilkRoadTest {
    
    private SilkRoad silkRoad;
    private SilkRoadSolver solver;
    
    @Before
    public void setUp() {
        int[] storePos = {10, 20, 30};
        int[] storeTenges = {100, 150, 200};
        int[] robotPos = {0, 15};
        
        int[][] days = {storePos, storeTenges, robotPos};
        silkRoad = SilkRoad.create(days);
        
        solver = new SilkRoadSolver(storePos, storeTenges, robotPos);
    }
    
    // ===============================================================
    // CICLO 1: ESTRUCTURA BASE
    // ===============================================================
    
    @Test
    public void shouldCreatePositionCorrectly() {
        Position pos = new Position(10);
        assertEquals(10, pos.getX());
        assertEquals(10, pos.getValue());
    }
    
    @Test
    public void shouldCalculateDistanceBetweenPositions() {
        Position p1 = new Position(10);
        Position p2 = new Position(25);
        assertEquals(15, p1.distanceToOther(p2));
    }
    
    @Test
    public void shouldCreateStoreWithCorrectAttributes() {
        Store store = new Store(20, 100);
        assertEquals(20, store.getPositionX());
        assertEquals(100, store.getTenges());
        assertTrue(store.isActive());
    }
    
    @Test
    public void shouldCreateRobotWithCorrectAttributes() {
        Robot robot = new Robot(5);
        assertEquals(5, robot.getPosition().getX());
        assertEquals(0, robot.getCollectedTenges());
        assertTrue(robot.isActive());
    }
    
    @Test
    public void shouldCollectTengesFromStore() {
        Store store = new Store(10, 100);
        Robot robot = new Robot(10);
        
        int collected = robot.collectFromStore(store);
        assertEquals(100, collected);
        assertEquals(0, store.getTenges());
    }
    
    @Test
    public void shouldNotCollectIfNotInSamePosition() {
        Store store = new Store(10, 100);
        Robot robot = new Robot(20);
        
        int collected = robot.collectFromStore(store);
        assertEquals(0, collected);
        assertEquals(100, store.getTenges());
    }
    
    @Test
    public void shouldResupplyStore() {
        Store store = new Store(10, 100);
        store.collect(100);
        assertEquals(0, store.getTenges());
        
        store.resupply();
        assertEquals(100, store.getTenges());
    }
    
    @Test
    public void shouldTrackRobotMovement() {
        Robot robot = new Robot(0);
        robot.moveToNewPos(10);
        robot.moveToNewPos(20);
        
        List<Position> history = robot.getMovementHistory();
        assertEquals(3, history.size());
        assertEquals(0, history.get(0).getX());
        assertEquals(10, history.get(1).getX());
        assertEquals(20, history.get(2).getX());
    }
    
    @Test
    public void shouldResetRobot() {
        Robot robot = new Robot(5);
        robot.moveToNewPos(15);
        robot.collect(50);
        
        robot.reset();
        assertEquals(5, robot.getPosition().getX());
        assertEquals(0, robot.getCollectedTenges());
    }
    
    // ===============================================================
    // CICLO 2: REQUISITOS 10-13
    // ===============================================================
    
    @Test
    public void shouldCreateSilkRoadFromMarathonInput() {
        assertNotNull(silkRoad);
        assertTrue(silkRoad.ok());
        assertEquals(3, silkRoad.stores().size());
        assertEquals(2, silkRoad.robots().size());
    }
    
    @Test
    public void shouldNotCreateWithInvalidInput() {
        int[][] invalidDays = {{10, 20}, {100, 150}};
        SilkRoad sr = SilkRoad.create(invalidDays);
        assertFalse(sr.ok());
    }
    
    @Test
    public void shouldNotCreateWhenStoresAndTengesMismatch() {
        int[][] invalidDays = {
            {10, 20, 30},
            {100, 150},
            {0}
        };
        SilkRoad sr = SilkRoad.create(invalidDays);
        assertFalse(sr.ok());
    }
    
    @Test
    public void shouldMoveRobotsAutomatically() {
        int[][] days = {{10, 30}, {100, 50}, {0}};
        SilkRoad sr = SilkRoad.create(days);
        
        sr.moveRobots();
        
        Robot robot = sr.robots().get(0);
        assertEquals(10, robot.getPosition().getX());
        assertTrue(robot.getCollectedTenges() > 0);
    }
    
    @Test
    public void shouldNotMoveWhenNoProfit() {
        int[][] days = {{100}, {10}, {0}};
        SilkRoad sr = SilkRoad.create(days);
        
        sr.moveRobots();
        
        Robot robot = sr.robots().get(0);
        assertEquals(0, robot.getPosition().getX());
        assertEquals(0, robot.getCollectedTenges());
    }
    
    @Test
    public void shouldReturnEmptiedStoresMatrix() {
        int[][] days = {{10}, {100}, {0}};
        SilkRoad sr = SilkRoad.create(days);
        
        sr.moveRobots();
        int[][] emptied = sr.emptiedStores();
        
        assertEquals(1, emptied.length);
        assertEquals(2, emptied[0].length);
        assertEquals(0, emptied[0][0]);
        assertEquals(1, emptied[0][1]);
    }
    
    @Test
    public void shouldReturnProfitPerMoveMatrix() {
        int[][] days = {{10}, {100}, {0}};
        SilkRoad sr = SilkRoad.create(days);
        
        sr.moveRobots();
        int[][] profits = sr.profitPerMove();
        
        assertEquals(1, profits.length);
        assertEquals(2, profits[0].length);
        assertEquals(0, profits[0][0]);
        assertEquals(100, profits[0][1]);
    }
    
    @Test
    public void shouldTrackEmptiedStoresCorrectly() {
        int[][] days = {{10}, {100}, {0}};
        SilkRoad sr = SilkRoad.create(days);
        
        sr.moveRobots();
        int[][] emptied1 = sr.emptiedStores();
        assertEquals(1, emptied1[0][1]);
        
        sr.resupply();
        sr.moveRobots();
        int[][] emptied2 = sr.emptiedStores();
        assertEquals(2, emptied2[0][1]);
    }
    
    @Test
    public void shouldHandleMultipleRobots() {
        int[][] days = {{10}, {100}, {0, 20}};
        SilkRoad sr = SilkRoad.create(days);
        
        sr.moveRobots();
        
        int total = 0;
        for (Robot r : sr.robots()) {
            total += r.getCollectedTenges();
        }
        assertEquals(100, total);
    }
    
    @Test
    public void shouldPlaceStoreAndRobotWithoutIds() {
        int[][] days = {{10}, {100}, {0}};
        SilkRoad sr = SilkRoad.create(days);
        
        Store newStore = sr.placeStore(50, 200);
        Robot newRobot = sr.placeRobot(25);
        
        assertNotNull(newStore);
        assertNotNull(newRobot);
        assertEquals(2, sr.stores().size());
        assertEquals(2, sr.robots().size());
    }
    
    @Test
    public void shouldRemoveStoreAndRobotByReference() {
        int[][] days = {{10}, {100}, {0}};
        SilkRoad sr = SilkRoad.create(days);
        
        Robot robot = sr.robots().get(0);
        Store store = sr.stores().get(0);
        
        sr.removeRobot(robot);
        sr.removeStore(store);
        
        assertEquals(0, sr.robots().size());
        assertEquals(0, sr.stores().size());
    }
    
    @Test
    public void shouldConsultStatistics() {
        int[][] days = {{10}, {100}, {0}};
        SilkRoad sr = SilkRoad.create(days);
        
        sr.moveRobots();
        sr.consult();
        
        assertTrue(sr.ok());
    }
    
    // ===============================================================
    // CICLO 3: REQUISITOS 14-15
    // ===============================================================
    
    @Test
    public void shouldSolveMarathonProblem() {
        int maxProfit = solver.solve();
        assertEquals(315, maxProfit);
    }
    
    @Test
    public void shouldReturnOptimalAssignments() {
        solver.solve();
        List<SilkRoadSolver.Assignment> assignments = solver.getOptimalAssignments();
        
        assertEquals(2, assignments.size());
        
        Set<Integer> robots = new HashSet<>();
        Set<Integer> stores = new HashSet<>();
        for (SilkRoadSolver.Assignment a : assignments) {
            robots.add(a.robotIndex);
            stores.add(a.storeIndex);
        }
        assertEquals(2, robots.size());
        assertEquals(2, stores.size());
    }
    
    @Test
    public void shouldNotAssignNegativeProfit() {
        int[] storePos = {100};
        int[] storeT = {10};
        int[] robotPos = {0};
        SilkRoadSolver s = new SilkRoadSolver(storePos, storeT, robotPos);
        
        int profit = s.solve();
        assertEquals(0, profit);
        assertEquals(0, s.getOptimalAssignments().size());
    }
    
    @Test
    public void shouldAssignEachRobotAtMostOnce() {
        solver.solve();
        List<SilkRoadSolver.Assignment> assignments = solver.getOptimalAssignments();
        
        Set<Integer> robotsSeen = new HashSet<>();
        for (SilkRoadSolver.Assignment a : assignments) {
            assertFalse(robotsSeen.contains(a.robotIndex));
            robotsSeen.add(a.robotIndex);
        }
    }
    
    @Test
    public void shouldAssignEachStoreAtMostOnce() {
        solver.solve();
        List<SilkRoadSolver.Assignment> assignments = solver.getOptimalAssignments();
        
        Set<Integer> storesSeen = new HashSet<>();
        for (SilkRoadSolver.Assignment a : assignments) {
            assertFalse(storesSeen.contains(a.storeIndex));
            storesSeen.add(a.storeIndex);
        }
    }
    
    @Test
    public void shouldHandleEmptyRobots() {
        int[] storePos = {10, 20};
        int[] storeT = {100, 150};
        int[] robotPos = {};
        SilkRoadSolver s = new SilkRoadSolver(storePos, storeT, robotPos);
        
        int profit = s.solve();
        assertEquals(0, profit);
    }
    
    @Test
    public void shouldHandleEmptyStores() {
        int[] storePos = {};
        int[] storeT = {};
        int[] robotPos = {0, 10};
        SilkRoadSolver s = new SilkRoadSolver(storePos, storeT, robotPos);
        
        int profit = s.solve();
        assertEquals(0, profit);
    }
    
    @Test
    public void shouldReturnSolutionMatrix() {
        solver.solve();
        int[][] matrix = solver.getSolutionAsMatrix();
        
        for (int[] row : matrix) {
            assertEquals(3, row.length);
            assertTrue(row[0] >= 0);
            assertTrue(row[1] >= 0);
            assertTrue(row[2] > 0);
        }
    }
    
    @Test
    public void shouldSimulateSolutionCorrectly() {
        int[][] days = {
            {10, 20, 30},
            {100, 150, 200},
            {0, 15}
        };
        SilkRoad sr = SilkRoad.create(days);
        
        int[] storePos = {10, 20, 30};
        int[] storeT = {100, 150, 200};
        int[] robotPos = {0, 15};
        SilkRoadSolver s = new SilkRoadSolver(storePos, storeT, robotPos);
        s.solve();
        
        sr.simulate(s);
        
        int total = 0;
        for (Robot r : sr.robots()) {
            total += r.getCollectedTenges();
        }
        assertTrue(total > 0);
    }
    
    @Test
    public void shouldUpdateProfitsDuringSimulation() {
        int[][] days = {{10}, {100}, {0}};
        SilkRoad sr = SilkRoad.create(days);
        
        int[] storePos = {10};
        int[] storeT = {100};
        int[] robotPos = {0};
        SilkRoadSolver s = new SilkRoadSolver(storePos, storeT, robotPos);
        s.solve();
        
        sr.simulate(s);
        int[][] profits = sr.profitPerMove();
        
        assertEquals(2, profits[0].length);
        assertEquals(0, profits[0][0]);
        assertEquals(100, profits[0][1]);
    }
    
    @Test
    public void shouldHandleNullSolver() {
        int[][] days = {{10}, {100}, {0}};
        SilkRoad sr = SilkRoad.create(days);
        
        sr.simulate(null);
        assertTrue(sr.ok());
    }
    
    @Test
    public void shouldRobotsMoveToPrescribedStores() {
        int[][] days = {{10, 30}, {100, 200}, {0}};
        SilkRoad sr = SilkRoad.create(days);
        
        int[] storePos = {10, 30};
        int[] storeT = {100, 200};
        int[] robotPos = {0};
        SilkRoadSolver s = new SilkRoadSolver(storePos, storeT, robotPos);
        s.solve();
        
        sr.simulate(s);
        
        Robot robot = sr.robots().get(0);
        assertEquals(30, robot.getPosition().getX());
    }
    
    @Test
    public void shouldRebootResetAllCounters() {
        int[][] days = {{10}, {100}, {0}};
        SilkRoad sr = SilkRoad.create(days);
        
        sr.moveRobots();
        sr.reboot();
        
        int[][] emptied = sr.emptiedStores();
        assertEquals(0, emptied[0][1]);
    }
    
    @Test
    public void shouldValidateProfitCalculation() {
        int[] storePos = {10, 20};
        int[] storeT = {100, 80};
        int[] robotPos = {5, 25};
        SilkRoadSolver s = new SilkRoadSolver(storePos, storeT, robotPos);
        
        int profit = s.solve();
        
        List<SilkRoadSolver.Assignment> assignments = s.getOptimalAssignments();
        int calculatedProfit = 0;
        for (SilkRoadSolver.Assignment a : assignments) {
            calculatedProfit += a.profit;
        }
        assertEquals(profit, calculatedProfit);
    }
}