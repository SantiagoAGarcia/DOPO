/**
 * Muestra mensajes durante la simulación SilkRoad.
 * 
 * @author Buitrago - Garcia
 * @version 2.0
 */
public class MessageHandler {
    private boolean visible;
    
    /**
     * Constructor que inicializa el manejador de mensajes con la visibilidad especificada.
     * 
     * @param visible true si los mensajes deben mostrarse, false para ocultarlos
     */
    public MessageHandler(boolean visible) {
        this.visible = visible;
    }
    
    /**
     * Muestra un mensaje por consola solo si la visibilidad está activada.
     * Si visible es false, el mensaje no se imprime.
     * 
     * @param msg El mensaje a mostrar
     */
    public void showMessage(String msg) {
        if (visible) {
            System.out.println(msg);
        }
    }
    
    /**
     * Establece la visibilidad de los mensajes.
     * 
     * @param visible true para mostrar mensajes, false para ocultarlos
     */
    public void setVisible(boolean visible) {
        this.visible = visible;
    }
    
    /**
     * Verifica si los mensajes están configurados para ser visibles.
     * 
     * @return true si los mensajes se muestran, false si están ocultos
     */
    public boolean isVisible() {
        return visible;
    }
}