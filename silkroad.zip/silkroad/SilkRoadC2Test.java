import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;

/**
 * Clase de pruebas unitarias para la clase SilkRoad.
 * Estas pruebas cubren los requisitos de la simulación SilkRoad.
 * 
 * @version 1.0
 */
public class SilkRoadC2Test {

    private SilkRoad silkRoad;

    @BeforeEach
    public void setUp() {
        silkRoad = new SilkRoad(10);
    }
    
    /**
     * Test para verificar que al colocar una tienda, esta se agrega correctamente.
     */
    @Test
    public void accordingDAShouldAddStoreCorrectly() {
        Store store = silkRoad.placeStore(1, 5, 50);
        assertNotNull(store, "Store should be created.");
        assertEquals(1, store.getId(), "Store ID should match.");
        assertEquals(5, store.getPositionX(), "Store position should match.");
        assertEquals(50, store.getTenges(), "Store tenges should match.");
    }
    

    /**
     * Test para verificar que al eliminar una tienda, esta se elimina correctamente.
     */
    @Test
    public void accordingDAShouldRemoveStoreCorrectly() {
        silkRoad.placeStore(1, 5, 50);
        silkRoad.removeStore(1);
        boolean storeExists = silkRoad.stores().stream()
            .anyMatch(store -> store.getId() == 1);
        
        assertFalse(storeExists, "Store should be removed from the list.");
    }

    /**
     * Test para verificar que un robot se mueve correctamente a una nueva posición.
     */
    @Test
    public void accordingDBShouldMoveRobotCorrectly() {
        Robot robot = silkRoad.placeRobot(1, 0);
        silkRoad.moveRobot(1, 5);
        assertEquals(5, robot.getPosition().getX(), "Robot's position should be updated.");
    }

    /**
     * Test para verificar que el método `getBestRobot` devuelve el robot con las mayores ganancias.
     */
    @Test
    public void accordingDAShouldReturnBestRobot() {
        silkRoad.placeStore(1, 5, 50);
        silkRoad.placeStore(2, 8, 70);
        
        Robot robot1 = silkRoad.placeRobot(1, 0);
        Robot robot2 = silkRoad.placeRobot(2, 2);
        
        silkRoad.moveRobot(1, 5);
        silkRoad.moveRobot(2, 8);
        
        Robot bestRobot = silkRoad.getBestRobot();
        
        assertEquals(robot2.getId(), bestRobot.getId(), "Robot 2 should be the best robot with the highest earnings.");
    }
}